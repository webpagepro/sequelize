var assets = require('./assets');
var categories = require('./categories')
module.exports = function(app){

    assets,
    categories
};