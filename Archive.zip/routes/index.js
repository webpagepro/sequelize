const assetsController = require('../controllers/assets');
//const categoriesController = require('../controllers/categories');

module.exports = (app) => {
    app.get('/assets/:asset_id', (req, res) => res.status(200).send(
        req.params
    ));

 //app.get('/assets/:asset_id&category_id', assetsController.create);
   // app.post('/assets/:asset_id', assetsController.create);

 /*
   get('/', index.lookup);
   get('/assets', assets.getAll);
   get('/assets/:id', assets.getOne);
   post('/assets', assets.assetAdd);
   patch('/assets/:id', assets.assetEdit);
   get('/categories/:id', categories.getCategories);
   post('/categories', categories.categoryAdd);
   patch('/categories/:id', categories.categoryEdit);

*/

};